<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserci&oacute;n de datos</title>
    
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}" />
</head>
<body>
    <div class="wrapper">
        <h1>Inserta un equipo</h1>
        
        <div>
            <form action="insercion" method="POST">
                @csrf

                <div>
                    <label>Nombre del equipo</label>
                    <input id="nombreEquipo" name="nombreEquipo" type="text">
                </div>
                <div>
                    <input type="submit" value="Insertar">
                </div>
            </form>
        </div>
        
        <?php
            if (isset($resultadoOperacion)) {
                if ($resultadoOperacion) { // Si ha tenido exito la operacion de insercion
                    echo '<div class="exito">' . $mensaje . '</div>';
                } else {
                    if (isset($mensaje)) {
                        echo '<div class="fallo">' . $mensaje . '</div>';
                    } else {
                        echo '<div class="fallo">' . "Error: No se ha completado la operación en la BB.DD. Revisa en el código la consulta." . '</div>';
                    }
                }
                unset($resultadoOperacion);
            }
        ?>
        
        <div>
            <a href="../listado">Volver a la p&aacute;gina de inicio</a>
        </div>
    </div>
    
</body>
</html>