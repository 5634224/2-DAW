<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/**
 * App\Models\Equipo
 *
 * @property int $eqp_id
 * @property string $eqp_nombre
 * @property int $eqp_puntos
 * @property int $eqp_golesfavor
 * @property int $eqp_golescontra
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo query()
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo whereEqpGolescontra($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo whereEqpGolesfavor($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo whereEqpId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo whereEqpNombre($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Equipo whereEqpPuntos($value)
 * @mixin \Eloquent
 */
class Equipo extends Model
{
    use HasFactory;
//    protected $table = "equipos";
    protected $primaryKey = "eqp_id";
    public $timestamps = false; // La clase no incluirá los timestamps
    public static $columnas = ["eqp_id", "eqp_nombre", "eqp_puntos", "eqp_golesfavor", "eqp_golescontra"];
    
    /**
     * Funcion que devuelve un array con el nombre de las columnas del modelo asociado a la tabla de la BB.DD.
     * https://foroayuda.es/como-seleccionar-el-nombre-de-todas-las-columnas-de-una-tabla-en-laravel/#:~:text=Soluci%C3%B3n%3A%20Puede%20obtener%20el%20nombre%20de%20todas%20las,el%20nombre%20de%20la%20tabla%20Desde%20el%20modelo
     * @return array
     */
//    public static function getTableColumns() {
////        return $this->getConnection()->getSchemaBuilder()->getColumnListing(get_class($self) . "s");
//        //https://www.php.net/manual/en/function.get-called-class.php
//        //https://www.w3schools.com/PHP/func_string_strpos.asps
//        $name = substr(static::class, strrpos(static::class, "\\") + 1);
//        //get_called_class()
//        
//        return DB::getSchemaBuilder()->getColumnListing(strtolower($name). "s");
//    }
}
