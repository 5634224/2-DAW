<?php

namespace App\Http\Controllers;

use App\Models\Equipo;
//use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;

class EquipoController extends Controller
{
    private $columnas = ["eqp_id", "eqp_nombre", "eqp_puntos", "eqp_golesfavor", "eqp_golescontra"];

    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //$this->columnas[0], $this->columnas[1], $this->columnas[2], $this->columnas[3], $this->columnas[4]
//        $registros = DB::table("equipos")->select(Equipo::getTableColumns())->orderBy("eqp_puntos")->orderByRaw("(eqp_golesfavor - eqp_golescontra)")->get();
//        $columnas = Equipo::getTableColumns();
//        var_dump($columnas);
//        $registros = DB::table("equipos")->select($this->columnas[1], $this->columnas[2], $this->columnas[3], $this->columnas[4])->orderBy("eqp_puntos")->orderByRaw("(eqp_golesfavor - eqp_golescontra)")->get();
        $registros = Equipo::select($this->columnas)->orderByDesc("eqp_puntos")->orderByRaw("(eqp_golesfavor - eqp_golescontra) DESC")->get()->toArray();
//        var_dump($request);
        return view("listado")->with(["columnas" => ["Nombre del equipo", "Puntos", "Goles a favor", "Goles en contra"],
                                        "registros" => $registros]);
//                                        , "operacion" => $request->post()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("insercion");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nombreEquipo = $request->post("nombreEquipo");
        if (!isset($nombreEquipo)) { // Descarta que se haya enviado un valor nulo por el formulario
            return view("insercion")->with(["resultadoOperacion" => false,
                                            "mensaje" => "Por favor, introduce un nombre de equipo."]);
        }
        /*-- Verifica que no exista ya un equipo con ese nombre --*/
//        $coincidencias = DB::table("equipos")->where("eqp_nombre", $nombreEquipo)->count();
        $coincidencias = Equipo::where("eqp_nombre", $nombreEquipo)->count();
        if ($coincidencias > 0) {
            return view("insercion")->with(["resultadoOperacion" => false,
                                            "mensaje" => "Has intentado añadir un equipo que ya existe con ese nombre."]);
        }
        
        /*-- Una vez descartado todo, insertamos --*/
        $equipo = new Equipo();
        $equipo->eqp_nombre = $nombreEquipo;
        
        $resultadoOperacion = $equipo->save();
        if ($resultadoOperacion) {
            return view("insercion")->with(["resultadoOperacion" => $resultadoOperacion,
                                            "mensaje" => $equipo->eqp_nombre . " ha sido guardado en la tabla equipos."]);
            
//            return Response::redirectToRoute("insercionCorrecta")->withInput(["nombreEquipo" => $equipo->eqp_nombre,
//                                                                    "resultadoOperacion" => $resultadoOperacion]);
            
//            return redirect()->route("insercionCorrecta", ["resultadoOperacion" => $resultadoOperacion,
//                                                        "mensaje" => $equipo->eqp_nombre . " ha sido guardado en la tabla equipos."]);
        } else {
            return view("insercion")->with(["resultadoOperacion" => $resultadoOperacion]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Equipo  $equipo
     * @return \Illuminate\Http\Response
     */
    public function show(Equipo $equipo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Equipo  $equipo
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        /*-- Carga los equipos que hay --*/
        $equipos = Equipo::select($this->columnas[0], $this->columnas[1])->get()->toArray();
        
        /*-- Verifica que haya al menos dos equipos --*/
        if (sizeof($equipos) < 2) {
            return redirect()->route("operacion")->withInput(["resultadoOperacion" => false, 
                                                    "mensaje" => "Deben de existir al menos 2 equipos para poder registrar encuentros."]);
        }
//        var_dump($equipos);
        return view("edit")->with("equipos", $equipos);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Equipo  $equipo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        /*-- Recupera los valores del formulario --*/
        $idEquipo1 = $request->post("idEquipo1");
        $goles1 = $request->post("goles1");
        $idEquipo2 = $request->post("idEquipo2");
        $goles2 = $request->post("goles2");
        
        /*-- Verifica que el usuario no haya puesto el mismo equipo dos veces --*/
        if ($idEquipo1 == $idEquipo2) {
            return redirect()->route("actualizacionIncorrecta")->withInput(["mensaje" => "El partido no puede ser contra el mismo equipo."]);
        }
        
        /*-- Recupera el objeto ORM Eloquent con cada uno de los ids --*/
        $equipo1 = Equipo::find(intval($idEquipo1));
        $equipo2 = Equipo::find(intval($idEquipo2));
        
        /*-- Calcula los puntos que se va a llevar cada equipo --*/
        if ($goles1 > $goles2) {
//            if ($equipo1 instanceof Equipo) {
            $equipo1->increment("eqp_puntos", 3);
//            }
        } else if ($goles1 == $goles2) {
            $equipo1->increment("eqp_puntos", 1);
            $equipo2->increment("eqp_puntos", 1);
        } else { //goles1 < goles2
            $equipo2->increment("eqp_puntos", 3);
        }
        /*-- Asigna los goles a favor y en contra --*/
        $equipo1->increment("eqp_golesfavor", intval($goles1));
        $equipo1->increment("eqp_golescontra", intval($goles2));
        $equipo2->increment("eqp_golesfavor", intval($goles2));
        $equipo2->increment("eqp_golescontra", intval($goles1));
        
        /*-- Guarda los cambios en el objeto ORM y en la BB.DD --*/
        $equipo1->save();
        $equipo2->save();
        
        /*-- Redirige a la pagina de inicio --*/
        return redirect("/listado")->withInput(["resultadoOperacion" => true,
                                        "mensaje" => "Actualización de la clasificación: encuentro entre " .
                                        $equipo1->eqp_nombre . " (". $goles1 . ") y " .
                                        $equipo2->eqp_nombre . " (" . $goles2 . ")."]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Equipo  $equipo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Equipo $equipo)
    {
        /*-- Descarta que el equipo no exista --*/
        if (!isset($equipo)) {
            return redirect()->route("operacion")->withInput(["resultadoOperacion" => false,
                                        "mensaje" => "Error al eliminar el equipo " . $equipo->eqp_nombre . "."]);
        }
        
        /*-- Elimina el equipo de la tabla --*/
//        Equipo::destroy($equipo);
        $equipo->delete();
        
        return redirect()->route("operacion")->withInput(["resultadoOperacion" => true, "mensaje" => "Equipo " . $equipo->eqp_nombre .  " eliminado correctamente."]);
    }
}
