<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualización de partidos</title>
    
    <link rel="stylesheet" href="{{ asset('/css/custom.css') }}" />
</head>
<body>
    <div class="wrapper">
        <h1>Actualización de partidos</h1>
        <div>
            <form action="actualizacion" method="POST">
                @csrf
                
                <div>
                    <label>Equipo 1 </label>
                    <select name="idEquipo1">
                        <?php
                            if (isset($equipos)) {
                                foreach ($equipos as $equipo) {
                                    ?>
                                    <option value="<?php echo $equipo["eqp_id"]; ?>"><?php echo $equipo["eqp_nombre"]; ?></option>
                                    <?php
                                }
                            }
                        ?>
                    </select>
                    <label>N&uacute;mero de goles </label>
                    <input type="number" name="goles1" min="0" max="10" value="0">
                </div>
                
                <div>
                    <label>Equipo 2 </label>
                    <select name="idEquipo2">
                        <?php
                            if (isset($equipos)) {
                                foreach ($equipos as $equipo) {
                                    ?>
                                    <option value="<?php echo $equipo["eqp_id"]; ?>"><?php echo $equipo["eqp_nombre"]; ?></option>
                                    <?php
                                }
                            }
                        ?>
                    </select>
                    <label>N&uacute;mero de goles </label>
                    <input type="number" name="goles2" min="0" max="10" value="0">
                </div>
                
                <div>
                    <input type="submit" value="Registrar partido">
                </div>
            </form>
        </div>
        
        <?php
            /*-- Si recibe el mensaje de alguna operación realizada en el controlador --*/
            $mensaje = Request::old("mensaje"); // Obtiene el parámetro pasado por session desde la anterior ruta
            if (isset($mensaje)) {
                echo '<div class="fallo">' . $mensaje . "</div>";
//                session()->forget("mensaje");
            }
        ?>
        
        <div>
            <a href="../listado">Volver a la p&aacute;gina de inicio</a>
        </div>
    </div>
</body>
</html>