<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de equipos</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('/css/custom.css')); ?>" />
</head>
<body>
    <div class="wrapper">        
        <h1>Listado de equipos</h1>
        <div>
            <table class="tabla-clasificacion">
                <thead>
                    <?php
                        if (isset($columnas)) {
                            foreach($columnas as $col) {
                                echo "<th>";
                                echo $col;
                                echo "</th>";
                            }
                        }
                    ?>
                </thead>
                <tbody>
                    <?php
                        if (isset($registros)) {
//                            var_dump($registros);
                            foreach ($registros as $equipo) {
                                /*-- Abre la fila --*/
                                echo "<tr>";
//                                var_dump($equipo);
//                                echo $equipo->eqp_nombre;
//                                $columnas = $equipo->getAttributes();
//                                $columnas->toArray() = $equipo;
                                $columnas = $equipo;
//                                var_dump($columnas);
                                /*-- Recorre las columnas de la fila --*/
                                foreach ($columnas as $nombreCol => $columna) {
                                    if ($nombreCol != "eqp_id") {
                                        echo "<td>";
                                        echo $columna;
                                        echo "</td>";
                                    }
                                    
//                                    var_dump($columna);
                                }
                                
                                /*-- Botón para eliminar --*/
                                echo "<td>";
                                //<a href="{{url('/clasificacion'.$equipo->eqp_id)}}">
                                echo '<a href="../eliminacion/' . $columnas["eqp_id"] . '" >';
                                echo '<input type="button" value="Eliminar equipo">';
                                echo '</a>';
                                echo "</td>";
                                
                                /*-- Cierra la fila --*/
                                echo "</tr>";
                            }
                        }
                    ?>
                </tbody>
            </table>
            
        </div>
        
        <?php
            /*-- Si recibe el mensaje de alguna operación realizada en el controlador --*/
            $resultadoOperacion = Request::old("resultadoOperacion"); // Obtiene el parámetro pasado por session desde la anterior ruta
            $mensaje = Request::old("mensaje");
            if (isset($resultadoOperacion) && isset($mensaje)) {
                if ($resultadoOperacion == true) {
                    echo '<div class="exito">' . $mensaje . "</div>";
                } else {
                    echo '<div class="fallo">' . $mensaje . "</div>";
                }
//                session()->forget("mensaje");
            }
        ?>
        
        <div>
            <a href="../insercion"><input type="button" value="Añadir equipos"></a>
            <a href="../editar"><input type="button" value="Registrar encuentros"></a>
        </div>
    </div>
</body>
</html><?php /**PATH /var/www/tarea6.es/resources/views/listado.blade.php ENDPATH**/ ?>