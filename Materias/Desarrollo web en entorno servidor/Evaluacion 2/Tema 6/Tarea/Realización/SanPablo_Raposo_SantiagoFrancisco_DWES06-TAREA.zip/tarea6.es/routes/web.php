<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Route::post('/listado', "App\Http\Controllers\EquipoController@index")->name("operacionCorrecta");

Route::get('/listado', "App\Http\Controllers\EquipoController@index")->name("operacion");

Route::get('/insercion', "App\Http\Controllers\EquipoController@create");

Route::post('/insercion', "App\Http\Controllers\EquipoController@store");

Route::get("/eliminacion/{equipo}", "App\Http\Controllers\EquipoController@destroy");

Route::get("/editar", "App\Http\Controllers\EquipoController@edit")->name("actualizacionIncorrecta");

Route::post("/actualizacion", "App\Http\Controllers\EquipoController@update");

//App\Http\Controllers\