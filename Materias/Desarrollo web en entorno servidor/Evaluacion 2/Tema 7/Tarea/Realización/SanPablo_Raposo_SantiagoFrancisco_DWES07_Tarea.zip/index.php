<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>

    <script src="validacion.js"></script>
    <link rel="stylesheet" href="custom.css">
</head>
<body>
    <?php
        function conexionBD(string $hostname, string $username, string $password, string $database) {
            $conexion = new mysqli($hostname, $username, $password, $database);
            return $conexion;
        }
    ?>

    <div id="wrapper">
        <h1>Gestión de usuarios</h1>

        <?php
            /*-- Si llega por el post información ... --*/
            if (isset($_POST["dni"])) {
                /*-- Conecta con MySQL --*/
                $bdConexion = conexionBD("localhost", "super", "123456", "dwes07");

                /*-- Crea la consulta preparada --*/
                $sql = "INSERT INTO usuarios VALUES (NULL, ?, ?, ?)";
                $query = $bdConexion->stmt_init(); // Inicia un Statement
                $query->prepare($sql);
                $query->bind_param("sss", $_POST["dni"], $_POST["nombre"], $_POST["ciudad"]);

                /*-- Ejecuta la consulta --*/
                try {
                    $resultado = $query->execute();

                    if ($resultado) {
                        echo '<div class="verde">Usuario insertado correctamente en la BB.DD.</div>';
                        $_POST = array(); // Elimina los datos del POST
                    } else {
                        echo '<div class="rojo">Error al insertar usuario en la BB.DD.</div>';
                    }
                } catch (Throwable $th) {
                    echo '<div class="rojo">' . $th->getMessage() . '</div>';
                }

                /*-- Cierra la consulta y la conexion con la BB.DD --*/
                $query->close();
                $bdConexion->close();
            }
        ?>

        <form action="" method="post">
            <div>
                <label>DNI</label>
                <input type="text" placeholder="DNI" name="dni" maxlength="9">
            </div>
            
            <div>
                <label>Usuario</label>
                <input type="text" placeholder="Nombre" name="nombre">
            </div>
            
            <div>
                <label>Ciudad</label>
                <input type="text" placeholder="Ciudad" name="ciudad">
            </div>
            
            <div>
                <input type="submit" value="Crear">
            </div>
        </form>
    </div>
</body>
</html>