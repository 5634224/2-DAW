<?php

    /*====================================================
                    CONSTANTES
    =====================================================*/
    define("ACTUAL_DATE", "CURRENT_TIMESTAMP"); // Nombre de columna de la tabla DUAL de MySQL que permite trabajar con la fecha actual del sistema

    /*====================================================
                    FUNCIONES
    =====================================================*/
    /**
     * Realiza la conexion con la BB.DD.
     *
     * @param  string $hostname Nombre del host donde se aloja la BB.DD. (¿Puede ser una direccion?)
     * @param  string $username Nombre de usuario para acceder a MySQL.
     * @param  string $password Contraseña para acceder a MySQL.
     * @param  string $database Nombre de la base de datos a la que deseas conectarte.
     * @return object Un objeto de conexión con la BB.DD. 
     */
    function conexionBD(string $hostname, string $username, string $password, string $database) {
        $conexion = new mysqli($hostname, $username, $password, $database);
        return $conexion;
    }
        
    /**
     * Funcion polivalente para hacer cualquier tipo de consulta preparada MySQLi.
     *
     * @param  mysqli $bdConexion Proporciona un objeto de conexión con MySQL. 
     * @param  string $sql Proporciona una consulta con código de MySQL.
     * @param  array $parametros Array (numérico o asociativo) que proporciona parámetros para la consulta. Debe ser un array cuyos valores son los que se sustituyen en las interrogaciones (?) del código SQL.
     * @param  object $todo Proporciona una función a realizar tras la consulta a la BB.DD, que permita trabajar con los datos (en caso de SELECT) por cada fila.
     * @return bool true si se ha realizado la operación correctamente; false si no.
     */
    function bd_prep_consulta_mysqli(mysqli $bdConexion, string $sql, array $parametros = null, object $todo = null) {
        /*-- Crea la consulta preparada --*/
        $query = $bdConexion->stmt_init(); // Inicia un Statement
        $query->prepare($sql);

        /*-- Prepara los parámetros --*/
        if (isset($parametros)) {
            $tipo = ""; // Cadena que se le pasará al método bind_param para detectar los tipos de datos de los parámetros
            foreach ($parametros as &$value) {
                switch (gettype($value)) {
                    case "float":
                        $tipo .= "d"; // Double
                        break;
                    case "integer":
                        $tipo .= "i"; // Integer
                        break;
                    case "string":
                        $tipo .= "s"; // String
                        break;
                    case "object":
                        $tipo .= "b"; // Binary
                        break;
                    case "array":
                        $tipo .= "b"; // Binary
                        break;
                    case "null":
                        $tipo .= "s";
                        $value = "NULL";
                        break;
                }
                $query->bind_param($tipo, $parametros);
            }
        }

        /*-- Ejecuta la consulta --*/
        $resultado = $query->execute();
        
        /*-- Trabajar con los datos (opcional, siempre que la consulta sea de tipo Select) --*/
        if (stripos($sql, "select") !== false && $todo != null) { // Es una consulta SELECT (Read)
            //https://es.stackoverflow.com/questions/209242/consulta-preparada-mysqli
            $datos = $query->get_result();
            while ($row = $datos->fetch_row()) { // Por cada fila (fetch row = array numérico)
                // https://lenguajes.com.mx/funciones-anonimas-de-php/#:~:text=Para%20usar%20una%20funci%C3%B3n%20an%C3%B3nima%2C%20debe%20asignarla%20a,%28%24x%2C%20%24y%29%20%7B%20return%20%24x%20%2A%20%24y%3B%20%7D%3B
                $todo($row); // Llama a la función anónima pasada por parámetro a la función
            }
        }

        /*-- Cierra la consulta --*/
        $query->close();

        /*-- Devuelve el resultado de la operación --*/
        return $resultado;
    }

    /**
     * Función que devuelve los datos de una consulta SELECT en MySQL.
     *
     * @param  mysqli $bdConexion Proporciona un objeto de conexión con MySQL. 
     * @param  string $sql Proporciona una consulta con código de MySQL.
     * @param  array $parametros Proporciona parámetros para la consulta. Debe ser un array cuyos valores son los que se sustituyen en las interrogaciones (?) del código SQL.
     * @return array|bool Devuelve un array con los datos de la consulta MySQL.
     */
    function bdSelect(mysqli $bdConexion, string $sql, array $parametros = null) {
        /*-- Declaración de variables --*/
        $datos = array();

        $todo = function (array $row) {
            global $datos;
            $datos[] = $row; // Agrega la fila al array de datos
        };

        /*-- Llama a la función para consultar la BB.DD --*/
        $resultado = bd_prep_consulta_mysqli($bdConexion, $sql, $parametros, $todo);
        
        /*-- Devuelve los datos en forma de array --*/
        if ($resultado) {
            return $datos;
        } else {
            return false;
        }
    }

    /**
     * Función que inserta datos en MySQL.
     *
     * @param  mysqli $bdConexion Proporciona un objeto de conexión con MySQL. 
     * @param  string $nombreTabla Proporciona el nombre de la tabla donde se quiere insertar un registro.
     * @param  array $datos Array asociativo que contiene key = columna, value = valor que se le quiere asignar a esa columna.
     * @return bool Devuelve true si la operacion tiene exito, false si no.
     */
    function bdInsert(mysqli $bdConexion, string $nombreTabla, array $datos) {
        /*-- Prepara el codigo SQL --*/
        $sql = "INSERT INTO " . $nombreTabla . " ";
        $columnas = "(";
        $valores = " VALUES (";
        
        foreach ($datos as $columna => $value) {
            $columnas .= $columna . ", ";
            $valores .= "?, ";
        }

        rtrim($columnas, ", "); // https://www.php.net/manual/es/ref.strings.php
        rtrim($valores, ", "); // https://www.php.net/manual/es/ref.strings.php
        $columnas .= ")";
        $valores .= ")";

        /*-- Define la cadena con el codigo SQL completo --*/
        $sql .= $columnas . " " . $valores;

        /*-- Llama a la función para consultar la BB.DD --*/
        $resultado = bd_prep_consulta_mysqli($bdConexion, $sql, $datos);
        
        /*-- Devuelve el resultado de la operación --*/
        return $resultado;
    }
        
    /**
     * Función que actualiza datos en MySQL.
     *
     * @param  mysqli $bdConexion Proporciona un objeto de conexión con MySQL. 
     * @param  string $nombreTabla Proporciona el nombre de la tabla donde se quiere actualizar los datos de uno/varios registros.
     * @param  array $datos Array asociativo que contiene key = columna, value = valor que se le quiere asignar a esa columna. No permite incremento de valores, puesto que al ser una consulta preparada, no permite inyección de código SQL.
     * @param  array $where Array asociativo que contiene las columnas y valores (key = columna, value = valor) que se utilizarán como criterio para determinar qué registros actualizar.
     * @return bool Devuelve true si la operacion tiene exito, false si no.
     */
    function bdUpdate(mysqli $bdConexion, string $nombreTabla, array $datos, array $where) {
        /*-- Prepara el codigo SQL --*/
        $sql = "UPDATE " . $nombreTabla . " ";

        /*-- Prepara los datos en la consulta --*/
        foreach ($datos as $columna => $value) {
            $sql .= $columna . " = ?, ";
        }
        rtrim($sql, ", "); // Elimina el sobrante , : https://www.php.net/manual/es/ref.strings.php
        
        /*-- Añade el WHERE --*/
        $sql .= " WHERE ";
        foreach ($where as $columna => $value) {
            $sql .= $columna . " = ? AND ";
        }
        rtrim($sql, " AND "); // Elimina el sobrante  AND  https://www.php.net/manual/es/ref.strings.php

        /*-- Une los arrays de $datos y $where, para pasárselos en un único argumento de "parámetros" a la función de consultas --*/
        $unionParametros = array_merge($datos, $where);

        /*-- Llama a la función para consultar la BB.DD --*/
        $resultado = bd_prep_consulta_mysqli($bdConexion, $sql, $unionParametros);

        /*-- Devuelve el resultado de la operación --*/
        return $resultado;
    }
        
    /**
     * Función que permite eliminar filas de una tabla MySQL.
     *
     * @param  mysqli $bdConexion
     * @param  string $nombreTabla
     * @param  array $where
     * @return bool Devuelve true si la operacion tiene exito, false si no.
     */
    function bdDelete(mysqli $bdConexion, string $nombreTabla, array $where = null) {
        /*-- Prepara el código SQL --*/
        $sql = "DELETE FROM " . $nombreTabla . "";

        /*-- Añade el WHERE --*/
        if (isset($where)) {
            $sql .= " WHERE ";
            foreach ($where as $columna => $value) {
                $sql .= $columna . " = ? AND ";
            }
        }

        /*-- Llama a la función para consultar la BB.DD --*/
        $resultado = bd_prep_consulta_mysqli($bdConexion, $sql, $where);

        /*-- Devuelve el resultado de la operación --*/
        return $resultado;
    }

    class MyORM {
        /*===================================================
                        ATRIBUTOS
        ====================================================*/
        /**
         * Atributo que almacena la conexión con la BB.DD
         */
        private mysqli $bdConexion;

        /**
         * Atributo que guarda el nombre de la tabla.
         */
        private string $nombreTabla;

        /**
         * Array asociativo que los datos de una fila guardando key (columna), dato.
         */
        private array $atributos;

        /**
         * Array numérico que contiene en cada posición, un array (por cada columna de la tabla) que, contiene los atributos de esa tabla (field, type, null, key, default y extra (Por ejemplo, auto_increment)).
         */
        private array $tiposDatos;

        /*===================================================
                        MÉTODOS
        ====================================================*/
        public function __construct(mysqli &$bdConexion, string $nombreTabla) {
            /*-- Realiza una consulta a la BB.DD para consultar las columnas de la tabla y crearlas dentro del array de $atributos --*/
            /*-- Función que se ejecutará por cada fila que recoja de la consulta (con datos de cada columna de la tabla) --*/
            $todo = function ($row) {
                if (stripos($row[1], "varchar") !== false || stripos($row[1], "char") !== false) {
                    $this->atributos[$row[0]] = "";
                    $this->tiposDatos[$row[0]] = $row;
                } else if (stripos($row[1], "integer") !== false) {
                    $this->atributos[$row[0]] = -1;
                    $this->tiposDatos[$row[0]] = $row;
                } else if (stripos($row[1], "decimal") !== false || stripos($row[1], "float") !== false || stripos($row[1], "double") !== false) {
                    $this->atributos[$row[0]] = 0.0;
                    $this->tiposDatos[$row[0]] = $row;
                } else if (stripos($row[1], "boolean") !== false) {
                    $this->atributos[$row[0]] = false;
                    $this->tiposDatos[$row[0]] = $row;
                } else if (stripos($row[1], "date") !== false) {
                    $fecha = DateTime::createFromFormat("Y-m-d", "1970-01-01");
                    $this->atributos[$row[0]] = $fecha;
                    $this->tiposDatos[$row[0]] = $row;
                } else if (stripos($row[1], "time") !== false) {
                    $fecha = DateTime::createFromFormat("H:i:s", "00:00:00");
                    $this->atributos[$row[0]] = $fecha;
                    $this->tiposDatos[$row[0]] = $row;
                } else if (stripos($row[1], "datetime") !== false) {
                    $fecha = DateTime::createFromFormat("Y-m-d H:i:s", "1970-01-01 00:00:00");
                    $this->atributos[$row[0]] = $fecha;
                    $this->tiposDatos[$row[0]] = $row;
                }
            };

            /*-- Declaracion de variables --*/
            $sql = "DESCRIBE " . $nombreTabla;

            /*-- Consulta de columnas --*/
            bd_prep_consulta_mysqli($bdConexion, $sql, null, $todo);

            /*-- Guarda los datos --*/
            $this->bdConexion = $bdConexion;
            $this->nombreTabla = $nombreTabla;
        }

        public static function from(mysqli &$bdConexion, string $nombreTabla, array $where): array|MyORM|null {
            /*-- Declaración de variables --*/
            $datos = array();
            $sql = "SELECT * FROM " . $nombreTabla;

            /*-- Añade el WHERE --*/
            $sql .= " WHERE ";
            foreach ($where as $columna => $value) {
                $sql .= $columna . " = ? AND ";
            }
            rtrim($sql, " AND "); // Elimina el sobrante  AND  https://www.php.net/manual/es/ref.strings.php

            /*-- Función anónima para agregar cada fila fila que recoja de la consulta en forma de objeto MyORM al array que devolverá (con datos de cada columna de la tabla) --*/
            $todo = function (array $row) {
                global $bdConexion, $nombreTabla, $datos; // Obtiene acceso a las variables de fuera de la función anónima
                $objeto = new MyORM($bdConexion, $nombreTabla);
                /*-- Añade la fila al objeto --*/
                foreach ($row as $columna => $value) {
                    $objeto->add($columna, $value);
                }

                $datos[] = $objeto; // Añade el objeto MyORM al array
            };

            /*-- Ejecuta la consulta --*/
            bd_prep_consulta_mysqli($bdConexion, $sql, null, $todo);

            /*-- Devuelve array (u objeto MyORM) --*/
            if (count($datos) == 0) {
                return null;
            } else if (count($datos) == 1) {
                return $datos[0];
            } else {
                return $datos;
            }
        }

        public function get(string $key) {
            // Si se ha modificado el valor en el objeto pero no se ha invocado a save, no se devuelve el valor anterior (el de la BB.DD), sino el valor nuevo que aún no ha sido guardado en la BB.DD
            return $this->atributos[$key];
        }

        private function add(string $key, string|int|float|object|array|null $value = null): void {
            $this->atributos[$key] = $value;
        }

        public function set(string $key, string|int|float|object|array|null $value = null) : bool {
            /*-- Descarta primero si la key no existe en el array de atributos --*/
            if (!array_key_exists($key, $this->atributos)) {
                return false;
            }

            /*-- Actualiza el valor de la key en el array de atributos --*/
            if (!isset($this->tiposDatos[$key]["anterior"])) {
                $this->tiposDatos[$key]["anterior"] = $this->atributos[$key]; // Actúa de bandera para el método save
            }
            $this->atributos[$key] = $value;

            return true;
        }

        public function save() {
            /*-- Declaración de variables --*/
            $parametros = array(); // Array que se compondrá solamente de aquellos parámetros que hayan sido modificados
            $where = array(); // Array que se compondrá de las columnas que actúen como clave primaria

            /*-- Rellena el array de parámetros y de where que enviaremos al método bdUpdate --*/
            foreach ($this->tiposDatos as $key => $value) {
                if (isset($value["anterior"])) {
                    $parametros[] = $this->atributos[$key];
                }

                if ($value[3] == "PRI") {
                    if (isset($value["anterior"])) {
                        $where[$key] = $value["anterior"];
                    } else {
                        $where[$key] = $this->atributos[$key];
                    }
                }
            }

            /*-- Ejecuta la actualización de datos en la BB.DD --*/
            $resultado = bdUpdate($this->bdConexion, $this->nombreTabla, $parametros, $where);

            if ($resultado == true) {
                foreach ($this->tiposDatos as $key => $value) {
                    if (isset($value["anterior"])) {
                        unset($this->tiposDatos[$key]["anterior"]); // Destruye la bandera para indicar que el valor ha sido actualizado en la BB.DD
                    }
                }
            }
            
            /*-- Devuelve el resultado --*/
            return $resultado;
        }

        public function remove() {
            
        }
    }
?>