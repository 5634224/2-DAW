<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperación 1ª evaluación</title>
</head>
<body>
    <?php
        require_once "bbdd_mysqli.php";
        /*-- Conexión --*/
        $bd = conexionBD("localhost", "super", "123456", "biblioteca");

        $datos = bdSelect($bd, "SELECT lib_titulo, lib_genero, lib_isbn
        FROM Libros;");

    ?>

    <h1>Libros</h1>
    <table border="1">
        <theader>
            <th>Título</th>
            <th>Género</th>
            <th>ISBN</th>
            <th>Ejemplares</th>
        </theader>
        <tbody>
            <?php
                for ($i=0; $i < count($datos); $i++) { 
                    ?>
                        <tr>
                            <td><?php echo $datos[$i][0] ?></td>
                            <td><?php echo $datos[$i][1] ?></td>
                            <td><?php echo $datos[$i][2] ?></td>
                            <td>
                                <form action="ejemplares.php" method="post">
                                    <input type="text" name="nombreLibro" value="<?php echo $datos[$i][0] ?>" hidden>
                                    <input type="text" name="isbnLibro" value="<?php echo $datos[$i][2] ?>" hidden>
                                    <input type="text" name="generoLibro" value="<?php echo $datos[$i][1] ?>" hidden>
                                    <input type="submit" value="Ejemplares">
                                </form>
                            </td>
                        </tr>
                    <?php
                }
            ?>
        </tbody>
    </table>

    <?php
        $bd->close();
    ?>
</body>
</html>