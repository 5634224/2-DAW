<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejemplares</title>

    <style>
        .back-rojo {
            background-color: red;
            color: white;
        }

        .verde {
            color: green;
        }
    </style>
</head>
<body>
    <?php
        require_once "bbdd_mysqli.php";
        /*-- Conexión con la BB.DD --*/
        $bd = conexionBD("localhost", "super", "123456", "biblioteca");

        /*-- Obtiene datos del POST --*/
        $nombreLibro = $_POST["nombreLibro"];
        $isbnLibro = $_POST["isbnLibro"];
        $generoLibro = $_POST["generoLibro"];

        function siguienteSignatura($isbn, $genero) {
            global $bd;
            /*-- Consulta a la BB.DD --*/
//            $resultado = bdSelect($bd, 'SELECT MAX(eje_signatura) FROM Ejemplares WHERE eje_libro = "' . $isbn . '" AND eje_signatura LIKE "' . $genero[0] . '__%"');
            $resultado = bdSelect($bd, 'SELECT MAX(eje_signatura) FROM Ejemplares WHERE eje_signatura LIKE "' . $genero[0] . '__%"');
            //SELECT MAX(eje_signatura) FROM Ejemplares WHERE eje_signatura LIKE "P__%"
            $numero = intval(substr($resultado[0][0], 1));
            $numero++;
            if ($numero < 10) {
                $resultado = $genero[0] . "0" . $numero; 
            } else {
                $resultado = $genero[0] . "" . $numero; 
            }

            /*-- Devuelve el resultado de la siguiente signatura calculada --*/
            return $resultado;
        }

        if (isset($nombreLibro)) {
            /*-- Realiza la consulta con la BB.DD --*/
            $datos = bdSelect($bd, "SELECT eje_signatura, pre_fecha, pre_devolucion, soc_nombre FROM Ejemplares
            LEFT JOIN Prestamos ON (eje_signatura = pre_ejemplar)
            LEFT JOIN Socios ON (pre_socio = soc_id)
            WHERE eje_libro = " . intval($isbnLibro));
    ?>

    <h1>Ejemplares</h1>
    <div id="contenido">
        <h3><?php echo $nombreLibro . " (" . $isbnLibro . ")"; ?></h3>
        <div id="insercionEjemplares">
            <form action="" method="post">
                <input type="text" name="nombreLibro" value="<?php echo $nombreLibro ?>" hidden>
                <input type="text" name="generoLibro" value="<?php echo $generoLibro ?>" hidden>
                <input type="text" name="isbnLibro" value="<?php echo $isbnLibro ?>" hidden>
                <input type="text" name="nuevoEjemplar" value="true" hidden>
                <input type="submit" value="Crear un nuevo ejemplar de este libro">
            </form>
            <div id="resultadoInsercion">
                <?php
                    if (array_key_exists("nuevoEjemplar", $_POST)) {
                        $signatura = siguienteSignatura($isbnLibro, $generoLibro);
//                        $enviarDatos = array("eje_libro" => $isbnLibro, "eje_signatura" => $signatura);
                        
                        $resultadoNuevoEjemplar = bd_prep_consulta_mysqli($bd, "INSERT INTO Ejemplares " . "(eje_libro, eje_signatura) VALUES (" . $isbnLibro . ", " . '"' . $signatura . '")');
                        if ($resultadoNuevoEjemplar) {
                        ?>
                            <span class="verde">Ha sido añadido un nuevo ejemplar correctamente (<?php echo $signatura ?>)</span>
                        <?php
                        }
                    }
                ?>
            </div>
        </div>
        <table border="1">
        <theader>
            <th>Signatura</th>
            <th>Fecha préstamo</th>
            <th>Fecha devolución</th>
            <th>Nombre socio</th>
        </theader>
        <tbody>
            <?php
                for ($i=0; $i < count($datos); $i++) { 
                    ?>
                        <tr <?php if (!isset($datos[$i][2]) && isset($datos[$i][3])) {echo 'class="back-rojo"';} ?>>
                            <td><?php echo $datos[$i][0] ?></td>
                            <td><?php echo $datos[$i][1] ?></td>
                            <td><?php echo $datos[$i][2] ?></td>
                            <td><?php echo $datos[$i][3] ?></td>
                        </tr>
                    <?php
                }
            ?>
        </tbody>
    </table>

        <?php
        }
        ?>
        

    </div>

    <div>
        <form action="index.php" method="post">
            <input type="submit" value="Regresar a la pantalla de inicio (Libros)">
        </form>
        
    </div>

    <?php
        $bd->close();
    ?>
</body>
</html>