<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Libro
 *
 * @method static \Illuminate\Database\Eloquent\Builder|Libro newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Libro newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Libro query()
 * @mixin \Eloquent
 */
class Libro extends Model
{
    use HasFactory;
    protected $primaryKey = "lib_isbn";
    public $timestamps = false;
}
