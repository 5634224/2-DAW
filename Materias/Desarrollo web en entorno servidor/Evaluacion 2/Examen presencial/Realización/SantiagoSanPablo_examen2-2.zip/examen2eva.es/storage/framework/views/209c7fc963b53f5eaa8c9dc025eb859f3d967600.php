<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Libros</title>
</head>
<body>
    <h1>Libros</h1>
    <?php
        var_dump($registros);
    ?>
    <div>
        <table border="1">
            <theader>
                <th>Título</th>
                <th>Género</th>
                <th>Autor</th>
                <th>ISBN</th>
                <th>Nº ejemplares prestados</th>
                <th>Nº ejemplares sin devolver</th>
            </theader>
            <tbody>
            <?php
                    foreach ($registros as $registro) { 
                        ?>
                            <tr>
                                <td><?php echo $registro ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="submit" name="x" value="<?php echo $registro ?>">
                                    </form>
                                </td>
                            </tr>
                        <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH /var/www/examen2eva.es/resources/views/index.blade.php ENDPATH**/ ?>