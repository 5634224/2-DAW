<?php
require_once "administrador.php";
require_once "programador.php";

class Departamento {
    private string $nombre;
    private array $trabajadores;
    private int $presupuestoMensual;
    
    public function __construct(string $nombre, int $presupuestoMensual) {
        $this->nombre = $nombre;
        $this->trabajadores = array();
        $this->presupuestoMensual = $presupuestoMensual;
    }
    
    public function getNombre(): string {
        return $this->nombre;
    }

    public function getTrabajadores(): array {
        return $this->trabajadores;
    }

    public function getPresupuestoMensual(): int {
        return $this->presupuestoMensual;
    }

    public function setNombre(string $nombre): void {
        $this->nombre = $nombre;
    }

//    public function setTrabajadores(array $trabajadores): void {
//        $this->trabajadores = $trabajadores;
//    }

    public function setPresupuestoMensual(int $presupuestoMensual): void {
        $this->presupuestoMensual = $presupuestoMensual;
    }


    /*-- Métodos del ejercicio --*/
    public function insertarTrabajador(Trabajador $trabajador) {
        if ($trabajador instanceof Programador || $trabajador instanceof Administrador) {
            /*-- Inserta el trabajador y devuelve true --*/
            $this->trabajadores[] = $trabajador;
            return true;
        }
        /*-- Si no ha podido insertar el trabajador --*/
        return false;
    }
    
    public function gastos() {
        $suma = $this->presupuestoMensual;
        foreach ($this->trabajadores as $trabajador) {
            $suma += $trabajador->getSueldo();
        }
        
        return $suma;
    }
}