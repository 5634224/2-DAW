<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <script src="formulario.js"></script>

        <style>
            div {
                margin-bottom: 1em;
            }

            .incorrecto {
                border-color: red;
                border-style: solid;
            }
        </style>
    </head>
    <body>
        <?php
            require_once "departamento.php";
            
            $miDepartamento;
            
            function inicializacion() {
                global $miDepartamento;
                $miDepartamento = new Departamento("IT Tecnologies", 10000);
                
                /*-- Añade la variable a la sesion --*/
                $_SESSION["miDepartamento"] = $miDepartamento;
            }
            
            /*===================================
                        GUION PHP
            ====================================*/
            /*-- Recupera los datos de la sesion --*/
            session_start(); // Inicia la sesion
            $miDepartamento = $_SESSION["miDepartamento"];

            /*-- Verifica si habia cargado algo en la sesion --*/
            if (isset($miDepartamento)) { // Existen datos en la sesion
                if (isset($_POST["reset"])) { // Si pide resetear la aplicacion
                    session_destroy();
                    session_start();
                    inicializacion();
                } else if (isset($_POST["aceptar"])) { // Si el usuario intenta meter datos en la aplicacion
                    $tipoTrabajador = $_POST["tipoTrabajador"];
                    if (isset($tipoTrabajador)) {
                        /*-- Obtiene todos los campos --*/
                        $id = $_POST["id"];
                        $nombre = $_POST["nombre"];
                        $sueldo = intval($_POST["sueldo"]);

                        switch ($tipoTrabajador) {
                            case "prog":
                                /*-- Campos del programador --*/
                                $lenguaje = $_POST["lenguaje"];
                                $sgbd = $_POST["sgbd"];

                                /*-- Crea el objeto y lo almacena en el objeto de departamento --*/
                                $programador = new Programador($id, $nombre, $sueldo, $lenguaje, $sgbd);
                                $miDepartamento->insertarTrabajador($programador);
                                break;
                            case "admin":
                                /*-- Campos del administrador --*/
                                $sistemaOperativo = $_POST["sistemaOperativo"];

                                /*-- Crea el objeto y lo almacena en el objeto de departamento --*/
                                $programador = new Administrador($id, $nombre, $sueldo, $sistemaOperativo);
                                $miDepartamento->insertarTrabajador($programador);
                                break;
                        }
                    }
                }
            } else { // No existen datos en la sesion
                inicializacion();
            }
        ?>
        
        <form action="" method="post">
            <div>
                <select name="tipoTrabajador">
                    <option value="seleccionar" selected disabled>Seleccionar una opción...</option>
                    <option value="prog">Programador</option>
                    <option value="admin">Administrador</option>
                </select>
            </div>

            <div>
                <label for="id">Identificación: </label>
                <input type="text" id="id" name="id" placeholder="Introduce tu identificacion">
            </div>

            <div>
                <label for="nombre">Nombre: </label>
                <input type="text" id="nombre" name="nombre" placeholder="Introduce tu nombre">
            </div>

            <div>
                <label for="sueldo">Sueldo: </label>
                <input type="number" id="sueldo" name="sueldo" placeholder="Introduce tu sueldo" min="0">
            </div>

            <!-- Campos opcionales, en funcion de si es programador o administrador -->
            <div>
                <fieldset id="programador">
                    <legend>Campos para programador</legend>
                    <div>
                        <label for="lenguaje">Lenguaje</label>
                        <input type="text" id="lenguaje" name="lenguaje" placeholder="Introduce tu lenguaje">
                    </div>
                    <div>
                        <label for="sgbd">Sistema Gestor de Bases de Datos</label>
                        <input type="text" id="sgbd" name="sgbd" placeholder="Introduce tu SGBD">
                    </div>
                </fieldset>
            </div>

            <div>
                <fieldset id="administrador">
                    <legend>Campos para administrador</legend>
                    <div>
                        <label for="sistemaOperativo">Sistema Operativo</label>
                        <input type="text" id="sistemaOperativo" name="sistemaOperativo" placeholder="Introduce tu S.O">
                    </div>
                </fieldset>
            </div>

            <div>
                <input type="submit" name="aceptar" value="Insertar">
                <!--<input type="submit" name="reset" value="Borrar datos y empezar de nuevo">-->
            </div>
        </form>

        <div id="contenido">
            <?php
                var_dump($miDepartamento);
            ?>
        </div>
    </body>
</html>
