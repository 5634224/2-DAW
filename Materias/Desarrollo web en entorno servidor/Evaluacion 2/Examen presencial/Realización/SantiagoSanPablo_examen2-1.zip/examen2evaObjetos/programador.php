<?php
require_once 'trabajador.php';

class Programador extends Trabajador {
    private string $lenguaje;
    private string $sgbd;
    
    public function __construct(string $identificacion, string $nombre, int $sueldo, string $lenguaje, string $sgbd) {
        parent::__construct($identificacion, $nombre, $sueldo);
        $this->lenguaje = $lenguaje;
        $this->sgbd = $sgbd;
    }

    public function getLenguaje(): string {
        return $this->lenguaje;
    }

    public function getSgbd(): string {
        return $this->sgbd;
    }

    public function setLenguaje(string $lenguaje): void {
        $this->lenguaje = $lenguaje;
    }

    public function setSgbd(string $sgbd): void {
        $this->sgbd = $sgbd;
    }


}