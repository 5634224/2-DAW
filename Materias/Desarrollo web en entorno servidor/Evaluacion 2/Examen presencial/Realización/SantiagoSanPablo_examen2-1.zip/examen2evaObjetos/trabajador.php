<?php
class Trabajador {
    protected string $identificacion;
    protected string $nombre;
    protected int $sueldo;
            
    public function __construct(string $identificacion, string $nombre, int $sueldo) {
        $this->identificacion = $identificacion;
        $this->nombre = $nombre;
        $this->sueldo = $sueldo;
    }

    public function getIdentificacion(): string {
        return $this->identificacion;
    }

    public function getNombre(): string {
        return $this->nombre;
    }

    public function getSueldo(): string {
        return $this->sueldo;
    }

    public function setIdentificacion(string $identificacion): void {
        $this->identificacion = $identificacion;
    }

    public function setNombre(string $nombre): void {
        $this->nombre = $nombre;
    }

    public function setSueldo(string $sueldo): void {
        $this->sueldo = $sueldo;
    }


}