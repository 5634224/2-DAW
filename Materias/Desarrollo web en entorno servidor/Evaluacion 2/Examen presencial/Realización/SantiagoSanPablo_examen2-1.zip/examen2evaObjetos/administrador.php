<?php
require_once 'trabajador.php';

class Administrador extends Trabajador {
    private string $sistemaOperativo;
    
    public function __construct(string $identificacion, string $nombre, int $sueldo, string $sistemaOperativo) {
        parent::__construct($identificacion, $nombre, $sueldo);
        $this->sistemaOperativo = $sistemaOperativo;
    }

    public function getSistemaOperativo(): string {
        return $this->sistemaOperativo;
    }

    public function setSistemaOperativo(string $sistemaOperativo): void {
        $this->sistemaOperativo = $sistemaOperativo;
    }



}