let form;
let tipoTrabajador;
let programador;
let administrador;

let inputNombreTrabajador;
let inputSueldo;
let inputIdentificacion;

document.addEventListener('DOMContentLoaded', () => {
    /*-- Declaración de variables --*/
    form = document.querySelector("form");
    tipoTrabajador = document.querySelector("select[name=tipoTrabajador]");
    programador = document.querySelector("#programador");
    administrador = document.querySelector("#administrador");

    inputNombreTrabajador = document.querySelector("#nombre");
    inputSueldo = document.querySelector("#sueldo");
    inputIdentificacion = document.querySelector("#id");

    /*-- Controla eventos --*/
    form.addEventListener("submit", fFormSubmit);
    tipoTrabajador.addEventListener("change", fTipoTrabajadorChange);
});

function fFormSubmit(evento) {
    /*-- Descarta que el nombre del trabajador sea incorrecto --*/
    let regularNombre = /^[A-ZÑ][a-zñ]*$/;
    if (!regularNombre.test(inputNombreTrabajador.value)) {
        inputNombreTrabajador.className = "incorrecto";
        evento.preventDefault();
    } else {
        inputNombreTrabajador.className = "";
    }

    /*-- Descarta que el sueldo sea incorrecto (no esté entre 1200 y 3000) --*/
    let sueldo = Number.parseInt(inputSueldo.value);
    // console.dir(inputSueldo);
    if (inputSueldo.value == "" || sueldo < 1200 || sueldo > 3000) {
        inputSueldo.className = "incorrecto";
        evento.preventDefault();
    } else {
        inputSueldo.className = "";
    }

    /*-- Descarta que la ID no cumpla con la expresion regular --*/
    let regularId = /^[A-ZÑ]\d{3}$/
    if (!regularId.test(inputIdentificacion.value)) {
        inputIdentificacion.className = "incorrecto";
        evento.preventDefault();
    } else {
        inputIdentificacion.className = "";
    }

    // evento.preventDefault();
    // alert("Exito");
}

function fTipoTrabajadorChange(evento) {
    // console.dir(evento.target.selectedIndex);
    if (evento.target.selectedIndex == 1) {
        administrador.setAttribute("disabled", "disabled");
        programador.removeAttribute("disabled");
    } else if (evento.target.selectedIndex == 2){
        programador.setAttribute("disabled", "disabled");
        administrador.removeAttribute("disabled");
    }
    // administrador.setAttribute("disabled", "disabled");
    // alert("exito");
}