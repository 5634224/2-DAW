<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Examen DWES</title>
    </head>
    <body>
        <?php
            require_once 'moduloConexion.php';
            
            /*-- Ejercicio 1 --*/
            function mostrarArticulos() {
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement

                $query->prepare("SELECT art_id, art_nombre, art_precio_venta "
                    . "FROM articulos "
                    . "GROUP BY art_id; ");
                $query->execute();
                $query->bind_result($idArticulo, $nombreArticulo, $precio);

                /*-- Imprime por pantalla los resultados devueltos desde la BB.DD --*/
                while ($query->fetch()) {
                    /*-- Codigo --*/
                    echo "<tr>";
                    echo "<td>";
                    echo "$idArticulo";
                    echo "</td>";
                    echo "<td>";
                    echo "$nombreArticulo";
                    echo "</td>";
                    echo "<td>";
                    echo "$precio";
                    echo "</td>";
                    
                    /*-- Imprime el boton de eliminar articulo --*/
                    echo "<td>";
                    echo '<form action="" method="post">';
                    echo '<input type="text" name="idEliminar" value="' . $idArticulo . '" hidden>';
                    echo '<input type="submit" value="Eliminar">';
                    echo "</form>";
                    echo "</td>";
                    /*-- Imprime el boton de editar articulo --*/
                    echo "<td>";
                    echo '<form action="editarArticulo.php" method="post">';
                    echo '<input type="text" name="idEditar" value="' . $idArticulo . '" hidden>';
                    echo '<input type="submit" name="editar" value="Editar">';
                    echo "</form>";
                    echo "</td>";
                    /*-- Cierra la fila --*/
                    echo "</tr>";
                }

                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
            }
            
            /*-- Ejercicio 2 --*/
            /**
             * Comprueba si un articulo tiene referencias en las tablas de lineas_ventas o carritos_compras
             * Devuelve true si el articulo se puede borrar, false si no.
             * @param type $idArticulo
             */
            function compruebaArticulo($idArticulo) {
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement
                
                $query->prepare("SELECT COUNT(car_articulo) " . 
                "FROM carritos_compra " . 
                "WHERE car_articulo = ?;");
                $query->bind_param("i", $idArticulo);
                $query->execute();
                $query->bind_result($numeroArticulosCarritos);
                $query->fetch();
                
                $query->prepare("SELECT COUNT(lin_articulo) " . 
                "FROM lineas_ventas " . 
                "WHERE lin_articulo = ?;");
                $query->bind_param("i", $idArticulo);
                $query->execute();
                $query->bind_result($numeroArticulosVendidos);
                $query->fetch();
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
                
                if ($numeroArticulosCarritos > 0 || $numeroArticulos > 0) {
                    return false;
                } else {
                    return true;
                }
            }
            
            /**
             * Funcion que elimina un articulo. Devuelve true si ha podido eliminarlo, false si no.
             * @param type $idArticulo
             * @return boolean
             */
            function eliminarArticulo($idArticulo) {
                if (!compruebaArticulo($idArticulo)) {
                    echo '<p style="color: red;">No se ha podido eliminar el articulo porque esta en algun carrito o en la tabla de ventas.</p>';
                    return false;
                }
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement
                
                $query->prepare("DELETE FROM articulos WHERE id_articulo = ?;");
                $query->bind_param("i", $idArticulo);
                $query->execute();
                //$query->bind_result($numeroArticulosCarritos);
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
            }
            
            /*=============================================
             *              GUION PHP
             =============================================*/
            $eliminar = $_POST["idEliminar"];
            //$editar = $_POST["editar"];
            if (isset($eliminar)) {
                eliminarArticulo($eliminar);
            }
        ?>
        
        <h1>Art&iacute;culos</h1>
        <table border="1">
            <thead>
                <th>ID</th>
                <th>Nombre</th>
                <th>Precio art&iacute;culo</th>
                <th>Eliminar articulo</th>
                <th>Editar articulo</th>
            </thead>
            <tbody>
                <?php
                    mostrarArticulos();
                ?>
            </tbody>
        </table>
    </body>
</html>
