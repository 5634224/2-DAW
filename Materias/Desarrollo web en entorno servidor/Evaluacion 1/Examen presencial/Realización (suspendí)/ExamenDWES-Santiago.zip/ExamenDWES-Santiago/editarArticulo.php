<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            require_once 'moduloConexion.php';
        
            $idArticulo;
            $nombreArticulo;
            $precioVenta;
            $precioCompra;
            $genero;
            
            function getInfoArticulo(&$idArticulo, &$nombreArticulo, &$precioVenta, &$precioCompra, &$genero) {
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement

                $query->prepare("SELECT art_id, art_nombre, art_precio_venta, art_genero, art_precio_compra "
                    . "FROM articulos "
                    . "WHERE art_id = ?; ");
                $query->bind_param("i", $idArticulo);
                
                $query->execute();
                $query->bind_result($idArticulo, $nombreArticulo, $precioVenta, $genero, $precioCompra);
                $query->fetch();
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
            }
        
            function imprimeListaGeneros($idArticulo) {                
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement

                $query->prepare("SELECT gen_id, gen_nombre FROM generos");
                
                $query->execute();
                $query->bind_result($idGen, $nombreGen);
                
                /*-- Imprime options dentro del select --*/
                global $genero;
                while ($query->fetch()) {
                    if ($idGen == $genero) {
                        echo '<option value="' . $idGen . '">' . $nombreGen . " selected</option>";
                    } else {
                        echo '<option value="' . $idGen . '">' . $nombreGen . "</option>";
                    }
                }
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
            }
            
            /**
             * Comprueba si un articulo tiene referencias en las tablas de lineas_ventas o carritos_compras
             * Devuelve true si el articulo se puede actualizar, false si no.
             * @param type $idArticulo
             */
            function compruebaArticulo($idArticulo) {
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement
                
                $query->prepare("SELECT COUNT(car_articulo) " . 
                "FROM carritos_compra " . 
                "WHERE car_articulo = ?;");
                $query->bind_param("i", $idArticulo);
                $query->execute();
                $query->bind_result($numeroArticulosCarritos);
                $query->fetch();
                
                $query->prepare("SELECT COUNT(lin_articulo) " . 
                "FROM lineas_ventas " . 
                "WHERE lin_articulo = ?;");
                $query->bind_param("i", $idArticulo);
                $query->execute();
                $query->bind_result($numeroArticulosVendidos);
                $query->fetch();
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
                
                if ($numeroArticulosCarritos > 0 || $numeroArticulos > 0) {
                    return false;
                } else {
                    return true;
                }
            }
            
            function agregarArticulo() {
                global $idArticulo;
                global $nombreArticulo;
                global $precioVenta;
                global $precioCompra;
                global $genero;
                
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement

                $query->prepare('INSERT INTO articulos VALUES ("", ?, ?, ?, ?); ');
                $query->bind_param("siii", $nombreArticulo, $precioVenta, $genero, $precioCompra);
                
                $query->execute();
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
                
                /*-- Mostramos mensaje por pantalla --*/
                echo '<p style="color: green;">Como hay un articulo en uso en otras tablas, hemos insertado el registro correctamente.</p>';
            }
            
            function editarArticulo() {
                global $idArticulo;
                global $nombreArticulo;
                global $precioVenta;
                global $precioCompra;
                global $genero;
                
                $bd = conectar();
                $query = $bd->stmt_init(); // Inicia un Statement

                $query->prepare("UPDATE SET art_nombre = ?, art_precio_venta = ?, art_gen = ?, art_precio_compra = ?");
                $query->bind_param("siii", $nombreArticulo, $precioVenta, $genero, $precioCompra);
                
                $query->execute();
                
                /*-- Cerramos la consulta y la conexión a la BB.DD --*/
                $query->close();
                $bd->close();
                
                /*-- Mostramos mensaje por pantalla --*/
                echo '<p style="color: green;">Hemos editado el registro correctamente.</p>';
            }

            /*=====================================
             *              GUION PHP
             ======================================*/
            
            session_start();
            if (isset($_POST["idEditar"]) && !isset($_SESSION["idEditar"])) {
                $_SESSION["idEditar"] = $_POST["idEditar"];
                
                if (isset($_POST["aceptar"])) {
                    /*-- Carga los datos desde el POST --*/
                    $idArticulo = $_SESSION["idEditar"];
                    $nombreArticulo = $_POST["nombreArticulo"];
                    $precioVenta = $_POST["precioVenta"];
                    $genero = $_POST["genero"];
                    $precioCompra = $_POST["precioCompra"];
                    if (!compruebaArticulo($idArticulo)) {
                        agregarArticulo();
                    } else {
                        editarArticulo();
                    }
                } else if (isset($_POST["cancelar"])) {
                    header('Location: index.php');
                } else {
                    /*-- Carga los datos --*/
                    getInfoArticulo($idArticulo, $genero, $precioVenta, $precioCompra, $genero);
                }
            } 
            
        ?>
        <h1>Formulario de edicion del articulo</h1>
        <form action="" method="post">
            <div>
                <label>ID Articulo</label>
                <input type="text" name="idEditar" value="<?php echo "$idArticulo"; ?>" disabled>
            </div>
            
            <div>
                <label>Nombre articulo</label>
                <input type="text" name="nombreArticulo" "<?php echo "$nombreArticulo"; ?>">
            </div>
            
            <div>
                <label>Precio de venta</label>
                <input type="text" name="precioVenta" "<?php echo "$precioVenta"; ?>">
            </div>
            
            <div>
                <label>Precio de compra</label>
                <input type="text" name="precioCompra" "<?php echo "$precioCompra"; ?>">
            </div>
            
            <div>
                <label>Genero</label>
                <select type="text" name="genero">
                    <?php
                        imprimeListaGeneros($idArticulo);
                    ?>
                </select>
            </div>
            
            <div>
                <input type="submit" name="aceptar" value="Aceptar">
                <input type="submit" name="cancelar" value="Cancelar">
            </div>
            
            <?php ?>
        </form>
    </body>
</html>
