<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        require_once 'conexion.php';
        $link = conecta_bd();

        if (isset($_POST["eliminar"])) {    // Apartado 2
            $art = $_POST["eliminar"];

            if (articulo_utilizado($art) > 0) {
                echo "El artículo con ID $art no puede ser eliminado, pues aparece en las ventas y/o carritos de compra<br><br>";
            } else {
                $consulta = "DELETE FROM articulos WHERE art_id = " . $art;
                $resultado = mysqli_query($link, $consulta);
                echo "El artículo con ID $art ha sido eliminado<br><br>";
            }
        }

        if (isset($_POST["modificar"])) {    // Apartado 4
            $id = $_POST["id"];
            $nombre = $_POST["nombre"];
            $precioventa = $_POST["precioventa"];
            $preciocompra = $_POST["preciocompra"];
            $genero = $_POST["genero"];

            if (articulo_utilizado($id) > 0) {
                $consulta2 = $link->stmt_init();   // Al estar utilizando cajas de texto en el formulario de inserción, es mejor optar por consultas preparadas
                $consulta2->prepare("INSERT INTO articulos VALUES (NULL,?,?,?,?)");    // Dejamos ID como nulo porque así tomará el valor automático al ser una columna auto incremental                                        
                $consulta2->bind_param("sdid", $nombre, $precioventa, $genero, $preciocompra);    // Asignamos los parámetros teniendo en cuenta los tipos de datos                
                $consulta2->execute();
                echo "El artículo con ID $id no puede ser modificado, pues aparece en las ventas y/o carritos de compra. Se ha creado una copia<br><br>";
            } else {
                $consulta2 = $link->stmt_init();   // Volvemos a utilizar consultas preparadas
                $consulta2->prepare("UPDATE articulos SET art_nombre=?,art_precio_venta=?,art_genero=?,art_precio_compra=? WHERE art_id=?");
                $consulta2->bind_param("sdidi", $nombre, $precioventa, $genero, $preciocompra,$id);    // En este caso sí que usaremos ID, pues modificados el artículo seleccionado
                $consulta2->execute();                
                echo "El artículo con ID $id ha sido modificado<br><br>";
            }
        }



        // Apartado 1

        $consulta = "SELECT * FROM articulos";
        $resultado = mysqli_query($link, $consulta);
        ?>                


        <table border="1">
            <tr><th>ID</th><th>Nombre</th><th>Precio venta</th><th>Precio compra</th><th>Eliminar</th><th>Editar</th></tr>        

            <?php
            while ($fila = mysqli_fetch_row($resultado)) {
                echo '<tr><td style="text-align:right">' . $fila[0] . '</td>';
                echo "<td>" . $fila[1] . "</td>";
                echo '<td style="text-align:right">' . number_format($fila[2], 2, ",") . "</td>"; // Muestro los dos precios del artículo, aunque tampoco era necesario
                echo '<td style="text-align:right">' . number_format($fila[4], 2, ",") . "</td>";

                echo '<td style="text-align:center">';  // Apartado 2
                echo '<form action="" method="post"><input type="submit" name="eliminar" value="' . $fila[0] . '">';
                echo "</form></td>";

                echo '<td style="text-align:center">';  // Apartado 3
                echo '<form action="edicion.php" method="post"><input type="submit" name="editar" value="' . $fila[0] . '">';
                echo "</form></td>";
                echo "</tr>";
            }
            ?>

        </table>

    </body>




</html>