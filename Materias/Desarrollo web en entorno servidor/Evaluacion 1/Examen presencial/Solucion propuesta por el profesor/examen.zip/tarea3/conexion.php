<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function conecta_bd() {
    $link = mysqli_connect('localhost', 'super', '123456', 'tienda');

    if (!$link) {
        echo "Error: no se puede conectar con la base de datos";
        exit;
    } else {
        return $link;
    }
}


function articulo_utilizado($art) { // Esta función nos va a valer tanto para la eliminación como para la edición
    $link = conecta_bd();
    
    $consulta = "SELECT COUNT(*) FROM lineas_ventas WHERE lin_articulo=".$art;    // Primero consultamos en las líneas de venta si aparece el artículo seleccionado
    $resultado = mysqli_query($link, $consulta);
    $fila = mysqli_fetch_row($resultado);
    
    if ($fila[0] > 0) {
        return 1;
    }
    
    $consulta = "SELECT COUNT(*) FROM carritos_compra WHERE car_articulo=".$art;  // Después en los carritos de compra
    $resultado = mysqli_query($link, $consulta);
    $fila = mysqli_fetch_row($resultado);
    
    if ($fila[0] > 0) {
        return 1;
    } else {
        return 0;   // Si ambas consultas han dado como resultado 0, es que el artículo no se está utilizando y puede ser eliminado o editado
    }   
}