<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        if (isset($_POST["editar"])) {
            require_once 'conexion.php';
            $link = conecta_bd();
            $art = $_POST["editar"];

            $consulta = "SELECT * FROM articulos WHERE art_id=" . $art;
            $resultado = mysqli_query($link, $consulta);
            $fila = mysqli_fetch_row($resultado);
            ?>                
            <form action="index.php" method="post">
                ID<input name="id" type="text" readonly="readonly" value="<?php echo $fila[0]; ?>"><br>
                Nombre<input name="nombre" type="text" value="<?php echo $fila[1]; ?>"><br>
                Precio de venta<input name="precioventa" type="text" value="<?php echo $fila[2]; ?>"><br><!-- comment -->
                Precio de compra<input name="preciocompra" type="text" value="<?php echo $fila[4]; ?>"><br>
                Género<select name="genero">

                    <?php
                    $consulta2 = "SELECT * FROM generos";
                    $resultado2 = mysqli_query($link, $consulta2);

                    while ($fila2 = mysqli_fetch_row($resultado2)) {
                        if ($fila2[0] == $fila[3]) {
                            echo '<option value="' . $fila2[0] . '" selected>' . $fila2[1] . "</option>";
                        } else {
                            echo '<option value="' . $fila2[0] . '">' . $fila2[1] . "</option>";
                        }
                    }
                    ?> <!-- Hasta aquí el apartado 3 -->


                </select><br>
                <input type="submit" name="modificar" value="Aceptar">
            </form>

            <?php
        }   // Cerramos el if con el que empieza el código PHP de esta página
        ?>

        <form action="index.php"> <!-- El botón de cancelar que pide el apartado 4 -->
            <input type="submit" value="Cancelar">            
        </form>

    </body>




</html>