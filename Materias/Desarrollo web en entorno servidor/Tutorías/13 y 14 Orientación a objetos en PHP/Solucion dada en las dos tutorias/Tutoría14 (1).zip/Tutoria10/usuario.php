<?php

require_once 'actividad.php';

class Usuario {

    private $nombre;
    private $nacimiento;
    private $sexo;
    private $actividades;

    public function getNombre() {
        return $this->nombre;
    }

    public function getNacimiento() {
        return $this->nacimiento;
    }

    public function getSexo() {
        return $this->sexo;
    }

    public function setNombre($nombre): void {
        $this->nombre = $nombre;
    }

    public function setNacimiento($nacimiento): void {
        $this->nacimiento = $nacimiento;
    }

    public function setSexo($sexo): void {
        $this->sexo = $sexo;
    }

    public function getActividades() {
        return $this->actividades;
    }

    public function __construct($nombre, $nacimiento, $sexo) {
        $this->nombre = $nombre;
        $this->nacimiento = $nacimiento;
        $this->sexo = $sexo;
        $this->actividades = array();
    }

    public function edad() {
        $fecha1 = new DateTime($this->nacimiento);
        $fecha2 = new DateTime(date("Y-m-d"));
        $diff = $fecha1->diff($fecha2);

        $d = $diff->days;
        $a = intdiv($d * 100, 36525);

        return $a;
    }

    public function insertaActividad($a) {
        if ($a instanceof Carrera || $a instanceof Ciclismo || $a instanceof Eliptica) {
            $this->actividades[] = $a;
        }            
    }

    public function totalCiclismo() {
        $distanciaTotal = 0;
        $ascensoTotal = 0;
        $tiempoTotal = 0;
        for ($i = 0; $i < count($this->actividades); $i++) {
            $c = $this->actividades[$i];
            if ($c instanceof Ciclismo) {
                $distanciaTotal += $c->getDistancia();
                $ascensoTotal += $c->getSubidaAcumulada();
                $tiempoTotal += $c->getDuracion();
            }
        }
        $km = $distanciaTotal / 1000;
        $h = $tiempoTotal / 3600;
        
        if ($h>0) {
            $vel= $km/$h;
        } else {
            $vel = 0;
        }
        
        $tc=array("distanciaTotal"=>$distanciaTotal,"ascensoTotal"=>$ascensoTotal,"tiempoTotal"=>$tiempoTotal,"velocidadMedia"=>$vel);
        
        return $tc;
    }
    
    public function totalCarrera() {
        $distanciaTotal = 0;
        $tiempoTotal = 0;
        for ($i = 0; $i < count($this->actividades); $i++) {
            $c = $this->actividades[$i];
            if ($c instanceof Carrera) {
                $distanciaTotal += $c->getDistancia();
                $tiempoTotal += $c->getDuracion();
            }
        }
        $km = $distanciaTotal / 1000;

        if ($km>0) {        
            $rit= $tiempoTotal/$km;
        } else {
            $rit = 0;
        }
        
        $tc=array("distanciaTotal"=>$distanciaTotal,"tiempoTotal"=>$tiempoTotal,"ritmo"=>$rit);
        
        return $tc;
    }    

    public function totalEliptica() {
        $pasosTotal = 0;
        $durezaTotal = 0;
        $tiempoTotal = 0;
        for ($i = 0; $i < count($this->actividades); $i++) {
            $e = $this->actividades[$i];
            if ($e instanceof Eliptica) {
                $tiempoTotal += $e->getDuracion();
                $pasosTotal += $e->getPasos();
                $durezaTotal += $e->getDureza();
            }
        }
                
        $te=array("pasosTotales"=>$pasosTotal,"durezaTotal"=>$durezaTotal,"tiempoTotal"=>$tiempoTotal);
        
        return $te;
    }    
    
    public function numeroActividades() {
        return count($this->actividades);
    }
    
    
    public function devuelveActividad($i) {
        $i=intval($i);
        if ($i<$this->numeroActividades() && is_int($i) && $i>=0) {
            return ($this->actividades[$i]);
        } else {
            return -1;
        }
    }
    
    public function eliminaActividad($i) {
        $i=intval($i);
        if ($i<$this->numeroActividades() && is_int($i) && $i>=0) {
            unset ($this->actividades[$i]);
            $this->actividades= array_values($this->actividades);   // Quitamos los huecos en el array de actividades
            return 0;            
        } else {            
            return -1;
        }
    }
    
    public function ordenaActividades() {
        $o=$this->actividades;  // En $o tendremos las actividades sin ordenar
        $d=array();             // En $d tendremos las actividades ordenadas, inicialmente este array estará vacío
        
        while (count($o) > 0) { // En cada ejecución del while tomaremos una actividad de $o y la pasaremos a $d, dejando $d siempre ordenado
            for ($i=0,$e=0; $i<count($o); $i++) {   // En el for se trata de seleccionar en $e el índice de la actividad con la fecha más temprana
                                                    // mediante $i buscamos en todos los elementos que quedan en $o
                $f1=DateTime::createFromFormat("Y-m-d", $o[$i]->getFecha());
                $f2=DateTime::createFromFormat("Y-m-d", $o[$e]->getFecha());

                if ($f1<$f2) {  // si la fecha de la actividad al que apunta $i es anterior a la de la actividad que apunta $e, tenemos que actualizar $e
                    $e=$i;
                }
            }
            
            $d[]=$o[$e];
            unset ($o[$e]);
            $o= array_values($o);
        }        
        
        $this->actividades=$d;  // Sustituimos las actividades del objeto por el array ya ordenado
    }    
}
