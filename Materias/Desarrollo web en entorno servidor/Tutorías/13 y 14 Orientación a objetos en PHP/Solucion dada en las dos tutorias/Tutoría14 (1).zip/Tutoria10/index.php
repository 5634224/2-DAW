<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>


        <?php
        require_once 'usuario.php';
        require_once 'conexion.php';

        //$a = new Actividad("12/01/2023", "17:00", 3690);
        //var_dump($a->getDuracion2());

        /* $c1=new Ciclismo("13/01/2023","17:00",3600,32000,500);
          $c2=new Ciclismo("14/01/2023","17:00",5000,40000,500);
          $c3=new Ciclismo("15/01/2023","17:00",2000,15000,200);


          $ca1=new Carrera("13/01/2023","17:00",3600,13000);
          $ca2=new Carrera("14/01/2023","17:00",3000,10000);
          $ca3=new Carrera("15/01/2023","17:00",4000,14000);

          $e1=new Eliptica("13/01/2023", "17:00", 3600, 5000, 6);
          $e2=new Eliptica("13/01/2023", "17:00", 3000, 6000, 3);
          $e3=new Eliptica("13/01/2023", "17:00", 4000, 7000, 6); */
        /* echo $c->velocidad()."<br>";

          $carr=new Carrera("13/01/2023", "17:00", 4000, 13500);
          $ritmo=$carr->ritmo();

          var_dump($ritmo);

          $e=new Eliptica("13/01/2023", "10:00", 4000, 10000,6);

          echo "<br>".$e->esfuerzo(); */

        /* $usu1=new Usuario("Pepe", "1980-01-19", "M");
          $usu1->insertaActividad($c1);
          $usu1->insertaActividad($c2);
          $usu1->insertaActividad($c3);

          $usu1->insertaActividad($ca1);
          $usu1->insertaActividad($ca2);
          $usu1->insertaActividad($ca3);

          $usu1->insertaActividad($e1);
          $usu1->insertaActividad($e2);
          $usu1->insertaActividad($e3);
          //echo $usu1->edad();

          $te=$usu1->totalEliptica();
          var_dump($te);

          $a=$usu1->devuelveActividad(2.5);
          var_dump($a); */


        session_start();

        if (isset($_POST["listausuario"])) {
            $link = conecta_bd();
            $consulta = "SELECT * FROM usuarios WHERE usu_id=" . $_POST["listausuario"];
            $resultado = mysqli_query($link, $consulta);
            $fila = mysqli_fetch_row($resultado);

            $_SESSION["usu_id"] = $fila[0];
            $_SESSION["u"] = new Usuario($fila[1], $fila[3], $fila[2]);

            $consulta2 = "SELECT * FROM actividades WHERE act_usuario=" . $_POST["listausuario"];
            $resultado2 = mysqli_query($link, $consulta2);

            while ($fila2 = mysqli_fetch_row($resultado2)) {
                if ($fila2[5] == NULL && $fila2[6] == NULL && $fila2[7] == NULL) {
                    $a = new Carrera($fila2[1], $fila2[2], $fila2[3], $fila2[4]);
                    $_SESSION["u"]->insertaActividad($a);
                } elseif ($fila2[6] == NULL && $fila2[7] == NULL) {
                    $a = new Ciclismo($fila2[1], $fila2[2], $fila2[3], $fila2[4], $fila2[5]);
                    $_SESSION["u"]->insertaActividad($a);
                } elseif ($fila2[4] == NULL && $fila2[5] == NULL) {
                    $a = new Eliptica($fila2[1], $fila2[2], $fila2[3], $fila2[6], $fila2[7]);
                    $_SESSION["u"]->insertaActividad($a);
                }

                $_SESSION["u"]->ordenaActividades();
            }
        }


        if (isset($_POST['salir']) && isset($_SESSION["usu_id"]) && isset($_SESSION["u"])) {       // Si hemos llegado hasta aquí con un usu_id, tenemos que guardar los cambios
            $link = conecta_bd();
            $consulta = "delete from actividades where act_usuario = " . $_SESSION["usu_id"];
            mysqli_query($link, $consulta);    // Eliminamos las actividades del usuario para volver a introducirlas

            for ($i = 0; $i < $_SESSION["u"]->numeroActividades(); $i++) {  // Guardamos todas las actividades que tenemos en el usuario

                $a = $_SESSION["u"]->devuelveActividad($i);
                if ($a instanceof Ciclismo) {       // Construimos INSERT dependiendo del tipo de actividad que tengamos
                    $consulta = "insert into actividades (act_fecha,act_hora,act_duracion,act_distancia,act_subidaacumulada,act_usuario) values ('" .
                            $a->getFecha() . "','" . $a->getHora() . "'," . $a->getDuracion() . "," . $a->getDistancia() . "," . $a->getSubidaAcumulada() . "," . $_SESSION['usu_id'] . ")";
                } elseif ($a instanceof Carrera) {
                    $consulta = "insert into actividades (act_fecha,act_hora,act_duracion,act_distancia,act_usuario) values ('" .
                            $a->getFecha() . "','" . $a->getHora() . "'," . $a->getDuracion() . "," . $a->getDistancia() . "," . $_SESSION['usu_id'] . ")";
                } elseif ($a instanceof Eliptica) {
                    $consulta = "insert into actividades (act_fecha,act_hora,act_duracion,act_pasos,act_dureza,act_usuario) values ('" .
                            $a->getFecha() . "','" . $a->getHora() . "'," . $a->getDuracion() . "," . $a->getPasos() . "," . $a->getDureza() . "," . $_SESSION['usu_id'] . ")";
                }

                mysqli_query($link, $consulta);                
            }
            unset($_SESSION["usu_id"]);         // Eliminamos los datos de la sesión
            unset($_SESSION["u"]);
        }

        if (isset($_POST["reinicio"])) {
            unset($_SESSION["u"]);
        }

        if (!isset($_SESSION["u"])) {   // En todo el archivo vamos a usar el usuario en $_SESSION directamente
            $link = conecta_bd();
            $consulta = "SELECT * FROM usuarios";
            $resultado = mysqli_query($link, $consulta);

            echo '<form action="" method=post>';
            echo '<select name="listausuario">';

            while ($fila = mysqli_fetch_row($resultado)) {
                echo '<option value="' . $fila[0] . '">' . $fila[1] . "</option>";
            }

            echo "</select><br>";
            echo '<input type="submit" value="Seleccionar">';
            echo "</form>";

//
        } else {
            ?>
            <form method="post" action="">
                Fecha<input type="text" name="fecha"><br>
                Hora<input type="text" name="hora"><br>
                Duración<input type="text" name="duracion"><br>
                Distancia<input type="text" name="distancia"><br>
                Subida Acumulada<input type="text" name="subidaacumulada"><br>
                Pasos<input type="text" name="pasos"><br>
                Dureza<input type="text" name="dureza"><br>
                <input type="submit" value="Enviar"><br><br>
            </form>             

    <?php
    if (isset($_POST['eliminar'])) {    // En primer lugar, miramos si ha llegado la orden de eliminar alguna de las actividades
        // si no es así, vamos buscando el tipo de actividad que se ha introducido, según los datos que se han rellenado
        $_SESSION["u"]->eliminaActividad($_POST['eliminar']);
    } elseif ($_POST["fecha"] != "" && $_POST["hora"] != "" && $_POST["duracion"] != "" && $_POST["distancia"] != "" && $_POST["subidaacumulada"] != "") {
        $a = new Ciclismo($_POST["fecha"], $_POST["hora"], $_POST["duracion"], $_POST["distancia"], $_POST["subidaacumulada"]);
        $_SESSION["u"]->insertaActividad($a);
        $_SESSION["u"]->ordenaActividades();
    } elseif ($_POST["fecha"] != "" && $_POST["hora"] != "" && $_POST["duracion"] != "" && $_POST["distancia"] != "") {
        $a = new Carrera($_POST["fecha"], $_POST["hora"], $_POST["duracion"], $_POST["distancia"]);
        $_SESSION["u"]->insertaActividad($a);
        $_SESSION["u"]->ordenaActividades();
    } elseif ($_POST["fecha"] != "" && $_POST["hora"] != "" && $_POST["duracion"] != "" && $_POST["pasos"] != "" && $_POST["dureza"] != "") {
        $a = new Eliptica($_POST["fecha"], $_POST["hora"], $_POST["duracion"], $_POST["pasos"], $_POST["dureza"]);
        $_SESSION["u"]->insertaActividad($a);
        $_SESSION["u"]->ordenaActividades();
    }

    //var_dump($_SESSION["u"]);

    echo '<table border="1">';  // Construimos la tabla con los datos de las actividades que hay en el usuario
    // En todo momento utilizamos los métodos de Usuario y las clases de las actividades
    echo '<tr bgcolor="#777777"><td>Fecha</td><td>Hora</td><td>Duración</td><td>Distancia</td><td>Subida Acumulada</td><td>Pasos</td><td>Dureza</td></tr>';

    for ($i = 0; $i < $_SESSION["u"]->numeroActividades(); $i++) {
        $a = $_SESSION["u"]->devuelveActividad($i);

        if ($a instanceof Ciclismo) {
            echo '<tr bgcolor="#FF7777">';
            echo "<td>" . $a->getFecha() . "</td>";
            echo "<td>" . $a->getHora() . "</td>";
            echo "<td>" . $a->getDuracion() . "</td>";
            echo "<td>" . $a->getDistancia() . "</td>";
            echo "<td>" . $a->getSubidaAcumulada() . "</td>";
            echo "<td>" . "</td>";
            echo "<td>" . "</td>";
        } else if ($a instanceof Carrera) {
            echo '<tr bgcolor="#77FF77">';
            echo "<td>" . $a->getFecha() . "</td>";
            echo "<td>" . $a->getHora() . "</td>";
            echo "<td>" . $a->getDuracion() . "</td>";
            echo "<td>" . $a->getDistancia() . "</td>";
            echo "<td>" . "</td>";
            echo "<td>" . "</td>";
            echo "<td>" . "</td>";
        } else if ($a instanceof Eliptica) {
            echo '<tr bgcolor="#7777FF">';
            echo "<td>" . $a->getFecha() . "</td>";
            echo "<td>" . $a->getHora() . "</td>";
            echo "<td>" . $a->getDuracion() . "</td>";
            echo "<td>" . "</td>";
            echo "<td>" . "</td>";
            echo "<td>" . $a->getPasos() . "</td>";
            echo "<td>" . $a->getDureza() . "</td>";
        }

        echo '<td><form action="" method="post">';  // Añadimos al final de cada fila un botón de eliminación de la misma
        echo '<input type="text" hidden="hidden" name="eliminar" value="' . $i . '"/>';
        echo '<input type="submit" value="' . $i . '" />';
        echo '</form></td>';

        echo "</tr>";
    }


    echo '</table>';

    $totalCiclismo = $_SESSION["u"]->totalCiclismo();
    $totalCarrera = $_SESSION["u"]->totalCarrera();
    $totalEliptica = $_SESSION["u"]->totalEliptica();

    var_dump($totalCiclismo);
    var_dump($totalCarrera);
    var_dump($totalEliptica);
}
?>

        <br><br>
        <form action="" method="post">
            <input type="submit" value="Guardar y salir" name="salir">
        </form>        


        <br><br>
        <form action="" method="post">
            <input type="submit" value="Reiniciar" name="reinicio">
        </form>
    </body>
</html>
