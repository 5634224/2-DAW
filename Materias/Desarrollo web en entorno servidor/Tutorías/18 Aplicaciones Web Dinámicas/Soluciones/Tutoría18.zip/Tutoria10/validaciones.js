/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */


function validar() {
    var validacion = /^[0-9]{4}[\-][0-9]{2}[\-][0-9]{2}$/
    
    campo=document.getElementById("fecha");
    
    //alert (campo.value);
    

    
    
    var validacion = /^[0-9]{2}[\:][0-9]{2}$/
    
    campo=document.getElementById("hora");
    
    //alert (campo.value);
    
    if (!validacion.test(campo.value)) {
        error=document.getElementById("horaerror");
        error.hidden=false;
        return false;
    }
    
    
    return true;
}