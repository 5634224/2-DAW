<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php

        // put your code here

        class Actividad {

            protected $fecha;
            protected $hora;
            protected $duracion;

            public function __construct($fecha, $hora, $duracion) {
                $this->fecha = $fecha;
                $this->hora = $hora;
                $this->duracion = $duracion;
            }

            public function getFecha() {
                return $this->fecha;
            }

            public function getHora() {
                return $this->hora;
            }

            public function getDuracion() {
                return $this->duracion;
            }

            public function setFecha($fecha): void {
                $this->fecha = $fecha;
            }

            public function setHora($hora): void {
                $this->hora = $hora;
            }

            public function setDuracion($duracion): void {
                $this->duracion = $duracion;
            }

            public function getDuracion2() {
                $segundos = $this->getDuracion();

                $s = $segundos % 60;

                $segundos = ($segundos - $s) / 60;
                $m = $segundos % 60;

                $h = ($segundos - $m) / 60;

                $dur2 = array("horas" => $h, "minutos" => $m, "segundos" => $s);

                return $dur2;
            }

        }

        class Ciclismo extends Actividad {

            private $distancia;
            private $subidaAcumulada;

            public function __construct($fecha, $hora, $duracion, $distancia, $subidaAcumulada) {
                $this->fecha = $fecha;
                $this->hora = $hora;
                $this->duracion = $duracion;
                $this->distancia = $distancia;
                $this->subidaAcumulada = $subidaAcumulada;
            }

            public function getDistancia() {
                return $this->distancia;
            }

            public function getSubidaAcumulada() {
                return $this->subidaAcumulada;
            }

            public function setDistancia($distancia): void {
                $this->distancia = $distancia;
            }

            public function setSubidaAcumulada($subidaAcumulada): void {
                $this->subidaAcumulada = $subidaAcumulada;
            }
            
            public function velocidad() {
                $km=$this->distancia/1000;
                $h=$this->duracion/3600;
                
                return $km/$h;
            }

        }
        
        class Carrera extends Actividad {
            private $distancia;
            
            public function __construct($fecha, $hora, $duracion, $distancia) {
                $this->fecha = $fecha;
                $this->hora = $hora;
                $this->duracion = $duracion;
                $this->distancia = $distancia;
            }            
            
            public function getDistancia() {
                return $this->distancia;
            }

            public function setDistancia($distancia): void {
                $this->distancia = $distancia;
            }


            public function ritmo() {
                $segundosPorKm=round($this->duracion/($this->distancia/1000));
                
                $s=$segundosPorKm%60;
                $m=($segundosPorKm-$s)/60;
                
                $ritmo=array("minutos"=>$m,"segundos"=>$s);
                
                return $ritmo;
            }
        }

        
        class Eliptica extends Actividad {
            private $pasos;
            private $dureza;
            
            public function __construct($fecha, $hora, $duracion, $pasos, $dureza) {
                $this->fecha = $fecha;
                $this->hora = $hora;
                $this->duracion = $duracion;
                $this->pasos = $pasos;
                $this->dureza = $dureza;
            }            
            
            public function getPasos() {
                return $this->pasos;
            }

            public function getDureza() {
                return $this->dureza;
            }

            public function setPasos($pasos): void {
                $this->pasos = $pasos;
            }

            public function setDureza($dureza): void {
                $this->dureza = $dureza;
            }

            public function esfuerzo() {
                return $this->pasos*$this->dureza;
            }
        }
        //$a = new Actividad("12/01/2023", "17:00", 3690);

        //var_dump($a->getDuracion2());
        
        $c=new Ciclismo("12/01/2023","17:00",3600,32000,500);
        
        echo $c->velocidad()."<br>";
        
        $carr=new Carrera("13/01/2023", "17:00", 4000, 13500);
        $ritmo=$carr->ritmo();
        
        var_dump($ritmo);
        
        $e=new Eliptica("13/01/2023", "10:00", 4000, 10000,6);
        
        echo "<br>".$e->esfuerzo();
        
        ?>


    </body>
</html>
