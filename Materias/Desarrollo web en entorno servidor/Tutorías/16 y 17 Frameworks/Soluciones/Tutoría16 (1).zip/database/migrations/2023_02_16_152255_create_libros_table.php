<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('libros', function (Blueprint $table) {
            $table->increments('lib_id'); // Crea una clave primaria autoincremental
            $table->string('lib_titulo'); // Columna tipo texto
            $table->integer('lib_paginas'); // Tipo entero
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('libros');
    }
};
