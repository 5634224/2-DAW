<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('autores', function (Blueprint $table) {
            $table->increments('aut_id');
            $table->string('aut_nombre');
        });

        Schema::table('libros', function (Blueprint $table) {
            $table->integer('lib_autor')->unsigned()->nullable();
            $table->foreign('lib_autor')->references('aut_id')->on('autores')->onDelete('set null'); // También podemos poner cascade o restrict
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::table('libros', function (Blueprint $table) {
            $table->dropForeign(['lib_autor']);
            $table->dropColumn('lib_autor');
        });
        
        Schema::dropIfExists('autores');
    }
};
