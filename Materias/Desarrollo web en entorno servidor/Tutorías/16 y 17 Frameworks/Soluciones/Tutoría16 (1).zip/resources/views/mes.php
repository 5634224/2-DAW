<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Desarrollo Web en Entorno Servidor</title>
    </head>
    <body>
        <p>Estamos en el mes de <?php echo $m; ?></p>
    </body>
</html>

