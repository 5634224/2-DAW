<!-- resources/views/basico.php -->
<!doctype html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Desarrollo Web en Entorno Servidor</title>
    </head>
    <body>
        <p>Página principal del curso mediante una vista.</p>
        
        <?php
            echo $p1."+".$p2."=";
        
            echo $p1+$p2;
        ?>
    </body>
</html>

