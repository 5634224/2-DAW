<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Autor extends Model {
    use HasFactory;
    protected $table = 'autores'; // Indicamos que cree una clase a partir de la tabla autores
    public $timestamps = false; // La clase no incluirá los timestamps
    protected $primaryKey = 'aut_id';
}
