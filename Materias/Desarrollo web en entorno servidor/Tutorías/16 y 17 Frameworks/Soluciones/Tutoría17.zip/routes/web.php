<?php

use Illuminate\Support\Facades\Route;
use App\Models\Autor;

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::get('/', function () {
    return view('welcome');
});

Route::get('/prueba-ruta', function () {

    return '¡Hola, mundo!';
});

Route::get('/factorial/{n}', function ($n) {
    for ($i = 1, $a = 1; $i <= $n; $i++)
        $a *= $i;
    return $a;
});

Route::get('/b', function () {

    return view('basico');
});

Route::get('/mes/{mes}', function ($mes) {
    //$mes = "Febrero";
    return view('mes')->with([
        'm' => $mes
    ]);
});

Route::get('/formulario2', function () {
    $dato1 = Request::get('p1');
    $dato2 = Request::get('p2');

    return view('basico')->with(["p1" => $dato1, "p2" => $dato2]);
});

Route::get('/formulario', function () {
    return view('formulario');
});

Route::get('/formulario3', function () {
    $dato1 = Request::get('p1');
    $dato2 = Request::get('p2');

    return view('nuevoformulario')->with(["p1" => $dato1, "p2" => $dato2]);
});

Route::get('/insercion', function () {
    $autor = new Autor; // Funciona con () y sin ellos
    $autor->aut_nombre = "Miguel de Cervantes";
    $autor->save(); // Método que guarda el objeto en la tabla
    echo 'Autor guardado en la tabla';
});

Route::get('/busqueda', function () {
    $autor = Autor::find('1');
    return $autor->aut_nombre;
});

Route::get('/actualizacion', function () {
    $autor = Autor::find(1);
    $autor->aut_nombre = "Calderón de la Barca";
    $autor->save();
    echo "Guardado";
});

Route::get('/listado', function () {
    $autores=Autor::where('aut_nombre', 'LIKE', '%Cal%')->get();
    //var_dump($autores); // Para ver todo el array
    
    
    foreach ($autores as $autor) {    
        echo $autor->aut_nombre."<br>"; // Para ver un elemento
    }
});

Route::get('/controlador', 'App\Http\Controllers\Controlador@index');