<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Controlador extends Controller
{
    public function index() {
        $dato1=DB::select("select libros.*, autores.* from libros join autores on libros.lib_autor=autores.aut_id");
        return view('vistaparacontrolador')->with(["p1" => $dato1]);       
    }
}

?>


