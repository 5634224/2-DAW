<!-- resources/views/basico.php -->
<!doctype html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Desarrollo Web en Entorno Servidor</title>
    </head>
    <body>
        <p>Página principal del curso mediante una vista.</p>
        
        <?php                    
            foreach ($p1 as $libro) {
                echo $libro->aut_id.$libro->aut_nombre." ".$libro->lib_titulo."<br>";
            }
        ?>
    </body>
</html>

