<html>
    <head>
        Formulario de ejemplo - DWES
    </head>
    <body>
        <br><br>
        <form action="formulario2" method="get">
            Parámetro 1<input type="text" name="p1"
                              id="p1"><br>
            Parámetro 2<input type="text" name="p2"
                              id="p2"><br>
            <input type="submit" value="Enviar" />
        </p>
    </form>
</body>
</html>
