<html>
    <head>
        Formulario de ejemplo - DWES
    </head>
    <body>
        <br>
        <?php
            $num=34;
        
            if (isset ($p1)) {
                if ($p1<$num) {
                    echo "El número buscado es mayor";
                } elseif ($p1>$num) {
                    echo "El número buscado es menor";
                } else {
                    echo "Has acertado el número";
                }
            } else {
                echo 'No se ha definido la variable $p1';
            }
        ?>
        
        
        <br><br>
        <form action="formulario3" method="get">
            Número<input type="text" name="p1"
                              id="p1"><br>
            <input type="submit" value="Enviar" />
        </p>
    </form>
</body>
</html>
