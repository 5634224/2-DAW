<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        if (!isset($_POST["nombre"])) {
            header("location: autenticacion.php");
        } else {
            $link= conecta_bd();
            $consulta='SELECT usu_password FROM usuarios WHERE usu_nombre="'.$_POST["nombre"].'"';
            $resultado= mysqli_query($link, $consulta);
            $fila= mysqli_fetch_row($resultado);
            
            if ($fila[0]!=md5($_POST["password"]) || !$fila || ($_POST["nombre"]!="isabel" && $_POST["nombre"]!="manuel")) {
                header("location: autenticacion.php");
            }
        }
        
        
        
        

        function conecta_bd() {
            $link = mysqli_connect('localhost', 'super', '123456', 'tienda');

            if (!$link) {
                echo "Error: no se puede conectar con la base de datos";
                exit;
            } else {
                return $link;
            }
        }

        session_start();

        if (isset($_SESSION["Proveedores"]) && !isset($_POST["eliminar"])) {
            $prov = $_SESSION["Proveedores"];
        } else {
            $prov = array();
        }

        if (isset($_POST['enviar'])) {
            $p = array($_POST['nombre'], $_POST['ciudad']);
            $prov[] = $p;
        }

        if (isset($_POST['volcar'])) {
            $link= conecta_bd();
            $consulta = $link->stmt_init();

            $consulta->prepare("INSERT INTO proveedores VALUES (NULL,?,?)");    // El primer valor es nulo porque la columno es autoincremental y tomará el valor automáticamente

            for ($i = 0; $i < count($prov); $i++) {
                $nom = $prov[$i][0];
                $ciu = $prov[$i][1];

                $consulta->bind_param("ss", $nom, $ciu);
                $consulta->execute();
            }
            $consulta->free_result();
            
            
            $prov = array();
        }
        ?>

        <table border="1">
            <tr><th>Nombre</th><th>Ciudad</th></tr>


            <?php
            for ($i = 0; $i < count($prov); $i++) {
                $f = $prov[$i];
                echo "<tr><td>" . $f[0] . "</td><td>" . $f[1] . "</td></tr>";
            }


            $_SESSION["Proveedores"] = $prov;
            ?>


        </table><br><br>    
        <form action="" method="post">
            Nombre<input type="text" name="nombre"><br><!-- comment -->
            Ciudad<input type="text" name="ciudad"><br><!-- comment -->
            <input type="submit" name="enviar" value="Enviar">
            <input type="submit" name="eliminar" value="Eliminar"><br><br>
            <input type="submit" name="volcar" value="Volcar">
        </form>


    </body>
</html>
