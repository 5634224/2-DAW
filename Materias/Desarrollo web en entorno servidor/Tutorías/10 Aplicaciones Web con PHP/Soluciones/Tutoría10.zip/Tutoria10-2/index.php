<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        session_start();

        if (isset($_SESSION["a"]) && !isset($_POST["Reiniciar"])) {
            $a = $_SESSION["a"];
            $t = $_SESSION["t"];
        } else {
            $f = array(" ", " ", " ", " ", " ", " ", " ");  // Para crear el array esta vez no voy a usar bucles
            $a = array($f, $f, $f, $f, $f, $f);             // Es más rápido crear la fila y el array directamente
            $t = "X";                                       // Empezamos colocando X
            $_SESSION["t"] = "X";                           // Puede que la primera vez no recibamos pulsación, y el siguiente bloque no se ejecute,
        }                                                   // por lo que tenemos que guardar en $_SESSION el caráctera a imprimir

        if (isset($_POST["col"])) {                         // Si hemos recibido algo en col, significa que hay una pulsación
            $i = 5;
            $c = $_POST["col"];                             // Buscamos en la columna pulsada el primer hueco
            while ($i >= 0 && $a[$i][$c] <> " ")
                $i--;

            if ($i >= 0) {
                $a[$i][$c] = $t;

                if ($t == "X") {
                    $_SESSION["t"] = "O";
                } else {
                    $_SESSION["t"] = "X";
                }
            }
        }

        echo '<table border="1">';                          // Imprimimos el array $a en la tabla
        for ($i = 0; $i < 6; $i++) {
            echo '<tr height="22">';
            for ($j = 0; $j < 7; $j++)
                echo '<td align="center">' . $a[$i][$j] . "</td>";
            echo "</tr>";
        }

        echo "<tr>";
        for ($j = 0; $j < 7; $j++) {                        // Al final de la tabla ponemos 7 botones
            echo '<td><form action="" method="post">';
            echo '<input type="text" name="col" value="' . $j . '" hidden="hidden"/>';
            echo '<input type="submit" value="Pulsar"/>';
            echo '</form></td>';
        }
        echo "</tr>";
        echo "</table>";
                

        $_SESSION["a"] = $a;
        ?>
        
        <br><br> <!-- El enunciado no pedía reinicio, pero ayuda bastante a depurar el código-->
        <form action="" method="post">
            <input type ="submit" value="Reiniciar" name="Reiniciar">            
        </form>
    </body>
</html>
