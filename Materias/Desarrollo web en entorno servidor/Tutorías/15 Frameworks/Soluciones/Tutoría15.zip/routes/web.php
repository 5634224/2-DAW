<?php

use Illuminate\Support\Facades\Route;

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::get('/', function () {
    return view('welcome');
});

Route::get('/prueba-ruta', function () {

    return '¡Hola, mundo!';
});

Route::get('/factorial/{n}', function ($n) {
    for ($i = 1, $a = 1; $i <= $n; $i++)
        $a *= $i;
    return $a;
});

Route::get('/b', function () {

    return view('basico');
});

Route::get('/mes/{mes}', function ($mes) {
    //$mes = "Febrero";
    return view('mes')->with([
        'm' => $mes
    ]);
});

Route::get('/formulario2', function () {
    $dato1 = Request::get('p1');
    $dato2 = Request::get('p2');
    
    return view('basico')->with(["p1"=>$dato1,"p2"=>$dato2]);      
});

Route::get('/formulario', function () {
    return view('formulario');
});
