<html>
   <head>
      <title>Tarea2b.com funciona</title>
   </head>
   <body>
      <h1>Dominio tarea2b.com</h1>
      <p><?php echo "DocumentRoot es: " . $_SERVER['DOCUMENT_ROOT'];?></p>
   </body>
</html>
