<html>
   <head>
      <title>Tarea2a.com funciona</title>
   </head>
   <body>
      <h1>Dominio tarea2a.com</h1>
      <p><?php echo "DocumentRoot es: " . $_SERVER['DOCUMENT_ROOT'];?></p>
   </body>
</html>
