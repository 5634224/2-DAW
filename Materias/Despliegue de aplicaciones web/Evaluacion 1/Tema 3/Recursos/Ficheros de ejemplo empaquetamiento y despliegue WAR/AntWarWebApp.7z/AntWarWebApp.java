public class AntWarWebApp {
 public static void main(String[] args) {
 System.out.println("Hola");}
}
