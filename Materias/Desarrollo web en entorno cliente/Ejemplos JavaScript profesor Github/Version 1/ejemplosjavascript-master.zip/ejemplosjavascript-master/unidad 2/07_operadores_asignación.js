/*
   Operador de asignación: =    
   Realizan la operación y después asignan +=    -=    *=    /=    %=   
   Realizan la operación (bits,poco utilizadas) <<=    >>= y después asignan
*/

let v1 = 2;
console.log(v1); 

v1 += 2;
console.log(v1)

v1 *= 2;
console.log(v1);

v1 <<= 1;// Operación binaria 1000 -> 10000
console.log(v1);
