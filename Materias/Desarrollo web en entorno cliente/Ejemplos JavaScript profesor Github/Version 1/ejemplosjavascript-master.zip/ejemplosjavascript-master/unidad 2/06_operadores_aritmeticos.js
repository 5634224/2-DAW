/*
    Operadores artiméticos
    +   -   *   /   %   ++   --
*/

let num1 = 12;
let num2 = 5;

console.log(`Suma: ${ num1 + num2 }`);
console.log(`Resta: ${ num1 - num2 }`);
console.log(`Multiplicación: ${ num1 * num2 }`);
console.log(`División: ${ num1 / num2 }`);
console.log(`Módulo: ${ num1 % num2 }`);
console.log(`Incremento: ${ ++num1 }`); //Incrementa antes de la sentencia
console.log(`Incremento: ${ num1-- }`); //Decrementa después de la sentencia.
