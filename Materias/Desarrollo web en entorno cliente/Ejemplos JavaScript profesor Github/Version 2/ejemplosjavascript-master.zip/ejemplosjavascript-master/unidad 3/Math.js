
/*
 
El objeto Math nos proporciona propiedades y métodos "estáticos", para 
trabajar con números

*/


console.log("Math.PI: "+Math.PI);
console.log("Math.SQRT2: "+Math.SQRT2);



console.log("Math.ceil(3.14): "+ Math.ceil(3.14));//->4
console.log("Math.floor(3.14) " + Math.floor(3.14));//->3
console.log("Math.pow(2,3) " + Math.pow(2,3));
console.log("Math.random() " + Math.random());
console.log("Math.min(5,7,8,3) " + Math.min(5,7,8,3));
console.log("Math.round(3.14) " + Math.round(3.14));



